
            import ScreenshotPreview from "./../../../../../components/ScreenshotPreview.tsx";

            const TempoComponent = () => {
              return <ScreenshotPreview />;
            }

            TempoComponent.getLayout = (page) => page;

            export default TempoComponent;