
            import Home from "./../../../../../components/home.tsx";

            const TempoComponent = () => {
              return <Home />;
            }

            TempoComponent.getLayout = (page) => page;

            export default TempoComponent;