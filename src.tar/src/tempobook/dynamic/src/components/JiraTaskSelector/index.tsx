
            import JiraTaskSelector from "./../../../../../components/JiraTaskSelector.tsx";

            const TempoComponent = () => {
              return <JiraTaskSelector />;
            }

            TempoComponent.getLayout = (page) => page;

            export default TempoComponent;