
            import StatusBar from "./../../../../../components/StatusBar.tsx";

            const TempoComponent = () => {
              return <StatusBar />;
            }

            TempoComponent.getLayout = (page) => page;

            export default TempoComponent;