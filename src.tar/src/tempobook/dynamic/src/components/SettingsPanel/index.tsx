
            import SettingsPanel from "./../../../../../components/SettingsPanel.tsx";

            const TempoComponent = () => {
              return <SettingsPanel />;
            }

            TempoComponent.getLayout = (page) => page;

            export default TempoComponent;