
            import ApiConfigSection from "./../../../../../components/ApiConfigSection.tsx";

            const TempoComponent = () => {
              return <ApiConfigSection />;
            }

            TempoComponent.getLayout = (page) => page;

            export default TempoComponent;