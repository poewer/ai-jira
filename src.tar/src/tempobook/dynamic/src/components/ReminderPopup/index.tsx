
            import ReminderPopup from "./../../../../../components/ReminderPopup.tsx";

            const TempoComponent = () => {
              return <ReminderPopup />;
            }

            TempoComponent.getLayout = (page) => page;

            export default TempoComponent;