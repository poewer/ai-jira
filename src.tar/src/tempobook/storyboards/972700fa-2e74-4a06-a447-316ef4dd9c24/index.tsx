import React from "react";

const Storyboard1 = () => {
  return <div/>;
};

export default Storyboard1;
